# Caça ao tesouro

O projeto é criar um jogo da velha que permita que dois jogadores joguem em um console de terminal. O jogo da velha é um jogo clássico em que dois jogadores alternam entre colocar "X" ou "O" em uma grade de 3x3 células. O objetivo do jogo é ser o primeiro a ter três símbolos consecutivos em linha, coluna ou diagonal.
